<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>01a - basisrouting</title>


    </head>
    <body>

    <h1>Welkom in de fantasy adventure world</h1>
    <nav>
        <ul>
            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li><a href="<?php echo e(route('wezens.show')); ?>">Wezens</a></li>
            <li><a href="<?php echo e(route('wezens.show', 'draak')); ?>">Draak</a></li>
            <li><a href="<?php echo e(route('koninkrijk.noord')); ?>">Noordelijk Koninkrijk</a></li>
            <li><a href="<?php echo e(route('koninkrijk.zuid')); ?>">Zuidelijk Koninkrijk</a></li>
        </ul>
    </nav>

</body>
</html>
 <?php /**PATH /Users/imac2019/Documents/CVO DeVerdieping - opleiding Full Stack Web Developer/15 - PHP - Laravel/github-laravel/01b_oefening_basiscontrollers/resources/views/welcome.blade.php ENDPATH**/ ?>