<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wezens</title>
</head>
<body>
<p><a href="<?php echo e(route('home')); ?>">Home</a></p>
    <h1>wezens: <?php echo e($wezen); ?></h1>
    <p>Als er geen OPTIONELE parameter wordt megegevens (bvb: 'draak') dan komt de STANDAARD 'wilde hond' in beeld</p>
</body>
</html><?php /**PATH /Users/imac2019/Documents/CVO DeVerdieping - opleiding Full Stack Web Developer/15 - PHP - Laravel/github-laravel/01a_oefening_basisrouting/resources/views/wezens/show.blade.php ENDPATH**/ ?>