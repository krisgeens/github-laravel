<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>01a - Wezens</title>
</head>
<body>

<h1>Wezens</h1>
<ul>
<li><a href= >
<li><a href= >
<li><a href= >
<li><a href= >
</ul>

</body>
</html><?php /**PATH /Users/imac2019/Documents/CVO DeVerdieping - opleiding Full Stack Web Developer/15 - PHP - Laravel/github-laravel/01a_oefening_basisrouting/resources/views/wezens.blade.php ENDPATH**/ ?>